package com.example.intheknow;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.CheckBox;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import android.util.Log;


import androidx.annotation.NonNull;


public class MainActivity extends AppCompatActivity {
    int counter = 3;
    //private DatabaseReference main_rtdb;
    SharedPreferences sp1;
    public static final String MyPREFERENCES = "MyPrefs" ;
    private static final String TAG = "EmailPassword";

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        sp1 = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        if(sp1.getBoolean("loggedIn", true)) {
            Intent myIntent = new Intent(MainActivity.this, HomeActivity.class);
            MainActivity.this.startActivity(myIntent);
        }

        mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_main);

        Button b1, b2;
        EditText ed1, ed2;
        TextView tx1, tx2, tx6;
        CheckBox chbx1;

        b1 = (Button) findViewById(R.id.button1);
        b2 = (Button) findViewById(R.id.button2);
        chbx1 = (CheckBox) findViewById(R.id.simpleCheckBox);
        ed1 = (EditText) findViewById(R.id.editText);
        ed2 = (EditText) findViewById(R.id.editText2);
        CheckBox finalChbx = chbx1;

        super.onStart();
        // Check if user is signed in (non-null) and update UI accordingly.
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if(currentUser != null){
            reload();
        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = ed1.getText().toString();
                String password = ed2.getText().toString();
                boolean remember = finalChbx.isChecked();

                if(remember) {
                    sp1.edit().putBoolean("loggedIn", true).apply();
                } else {
                    sp1.edit().putBoolean("loggedIn", false).apply();
                }

                while(email.isEmpty()) {
                    Toast.makeText(MainActivity.this, "You must enter your email address!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(password.isEmpty()) {
                    Toast.makeText(MainActivity.this, "You must enter your password!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Sign in success, update UI with the signed-in user's information
                                    Log.d(TAG, "signInWithEmail:success");
                                    FirebaseUser user = mAuth.getCurrentUser();
                                    Toast.makeText(MainActivity.this, "Authentication successful.",
                                            Toast.LENGTH_SHORT).show();

                                    Intent myIntent = new Intent(MainActivity.this, HomeActivity.class);
                                    MainActivity.this.startActivity(myIntent);
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w(TAG, "signInWithEmail:failure", task.getException());
                                    Toast.makeText(MainActivity.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();

                                    counter--;
                                    if(counter == 0) {
                                        b1.setEnabled(false);
                                        Toast.makeText(MainActivity.this, "Exceeded maximum number login attempts. Login button disabled. Restart app to try again.",
                                                Toast.LENGTH_LONG).show();
                                    }
                                }
                            }
                        });
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(MainActivity.this, CreateAccountActivity.class);
                MainActivity.this.startActivity(myIntent);
            }
        });
    }

//    private void signOut() {
//        mAuth.signOut();
//    }

    private void reload() {
        mAuth.getCurrentUser().reload().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (!task.isSuccessful()) {
                    Log.e(TAG, "reload", task.getException());
                    Toast.makeText(MainActivity.this,
                            "Failed to reload user.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(MainActivity.this,
                "The back button is disabled for this screen.",
                Toast.LENGTH_LONG).show();
    }
}






