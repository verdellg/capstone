package com.example.intheknow;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class HomeActivity extends AppCompatActivity {
    private FirebaseAuth mAuth; //DATABASE CODE: declares mAuth variable of type Firebase
    SharedPreferences sp1;
    public static final String MyPREFERENCES = "MyPrefs" ;
    private DatabaseReference main_rtdb; //DATABASE CODE: declares main_rtdb variable to store DatabaseReference
    String bldg_stat = "safe"; //string for comparison purposes

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        mAuth = FirebaseAuth.getInstance();
        sp1 = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);

        ImageView b1;
        ImageView b2;
        ImageView b3;
        ImageButton b4, b5;
        TextView tv1, tv2;

        b1 = (ImageView) findViewById(R.id.newlog); //new log
        b2 = (ImageView) findViewById(R.id.settings); //edit account
        b3 = (ImageView) findViewById(R.id.directory); //directory
        b4 = (ImageButton) findViewById(R.id.imgbtn1); //refresh
        b5 = (ImageButton) findViewById(R.id.imgbtn2); //sign out
        tv1 = (TextView) findViewById(R.id.textview_stat1); //building safe

        main_rtdb = FirebaseDatabase.getInstance().getReference(); //DATABASE CODE: gets instance of database and stores it in main_rtdb
        //DATABASE CODE- uses get() method to read from database
        //the value can be stored as a string using "String status = String.valueOf(task.getResult().getValue());"
        //change the child() from "building status" to "users" and then add another child for the current user
        //so something like main_rtdb.child("users").child(uEmail).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
        //they are identified in the database by their email (the period was removed to avoid an exception
        main_rtdb.child("building_status").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    String status = String.valueOf(task.getResult().getValue());
                    Toast.makeText(HomeActivity.this, "Refresh complete.", Toast.LENGTH_SHORT).show();
                    if(status.equals(bldg_stat)) {
                        tv1.setText("Safe");
                    } else {
                        tv1.setText("Unsafe");
                    }
                }
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(HomeActivity.this, NewLogActivity.class);

//                FirebaseUser rUser = mAuth.getCurrentUser(); //gets the current user info
//                String uEmail0 = rUser.getEmail(); //gets user email ***important***
//                String uEmail = uEmail0.replaceAll("\\.", ""); //removes periods from user email because Firebase can't have database children with the . character
//
//                myIntent.putExtra("uEmail", uEmail);

                HomeActivity.this.startActivity(myIntent);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(HomeActivity.this, EditAccountActivity.class);
                HomeActivity.this.startActivity(myIntent);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(HomeActivity.this, DirectoryActivity.class);
                HomeActivity.this.startActivity(myIntent);
            }
        });

        //refresh button
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //this is the same code as above, just implemented for the refresh button
                main_rtdb = FirebaseDatabase.getInstance().getReference(); //get new database reference
                main_rtdb.child("building_status").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DataSnapshot> task) {
                        if (!task.isSuccessful()) {
                            Log.e("firebase", "Error getting data", task.getException());
                        } else {
                            Log.d("firebase", String.valueOf(task.getResult().getValue()));
                            String status = String.valueOf(task.getResult().getValue());
                            Toast.makeText(HomeActivity.this, "Refresh complete.", Toast.LENGTH_SHORT).show();
                            if(status.equals(bldg_stat)) {
                                tv1.setText("Safe");
                            } else {
                                tv1.setText("Unsafe");
                            }
                        }
                    }
                });
            }
        });

        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseAuth.getInstance().signOut();
                sp1.edit().putBoolean("loggedIn", false).apply();
                Toast.makeText(HomeActivity.this, "You have been signed out.", Toast.LENGTH_SHORT).show();

                Intent myIntent = new Intent(HomeActivity.this, MainActivity.class);
                HomeActivity.this.startActivity(myIntent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        Toast.makeText(HomeActivity.this,
                "Please tap the sign out button at the top of the screen in order to sign out.",
                Toast.LENGTH_LONG).show();
    }
}