package com.example.intheknow;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;


public class CreateAccountActivity extends AppCompatActivity  {

    private DatabaseReference main_rtdb;
    private static final String TAG = "EmailPassword";

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_create_account);

        Button b1, b2;
        CheckBox chbx1;
        EditText ed1, ed2, ed3, ed4, ed5, ed6, ed7, ed8, ed9;


        b1 = (Button) findViewById(R.id.button1);
        b2 = (Button) findViewById(R.id.button2);
        chbx1 = (CheckBox) findViewById(R.id.simpleCheckBox);
        ed1 = (EditText) findViewById(R.id.editText);
        ed2 = (EditText) findViewById(R.id.editText2);
        ed3 = (EditText) findViewById(R.id.editText3);
        ed4 = (EditText) findViewById(R.id.editText4);
        ed5 = (EditText) findViewById(R.id.editText5);
        ed6 = (EditText) findViewById(R.id.editText6);
        ed7 = (EditText) findViewById(R.id.editText7);
        ed8 = (EditText) findViewById(R.id.editText8);
        ed9 = (EditText) findViewById(R.id.editText9);
        chbx1 = (CheckBox) findViewById(R.id.simpleCheckBox);

        CheckBox finalChbx = chbx1;
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String fname = ed1.getText().toString();
                String lname = ed2.getText().toString();
                String classification = ed3.getText().toString();
                String dob = ed4.getText().toString();
                String phone_num = ed5.getText().toString();
                String email = ed6.getText().toString();
                String email_conf = ed7.getText().toString();
                String password = ed8.getText().toString();
                String password_conf = ed9.getText().toString();
                boolean tcCheck = finalChbx.isChecked();

                while(fname.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter your first name!", Toast.LENGTH_SHORT).show();
                    return;
                }

                while(lname.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter your last name!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(dob.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter your date of birth!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(classification.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter your classification!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(phone_num.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter your phone number!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(email.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter your FAMU email address!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(email_conf.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please confirm your FAMU email address!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(password.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please enter a password!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(password_conf.isEmpty()) {
                    Toast.makeText(CreateAccountActivity.this, "Please confirm your password!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(!email.equals(email_conf)) {
                    Toast.makeText(CreateAccountActivity.this, "Email addresses do not match!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(!password.equals(password_conf)) {
                    Toast.makeText(CreateAccountActivity.this, "Passwords do not match!",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                while(!tcCheck) {
                    Toast.makeText(CreateAccountActivity.this, "Please agree to the Terms & Conditions before creating an account",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                mAuth.createUserWithEmailAndPassword(email, password)
                        .addOnCompleteListener(CreateAccountActivity.this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {

                                    Toast.makeText(CreateAccountActivity.this, "User creation successful.",
                                            Toast.LENGTH_SHORT).show();

                                    SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy 'at' HH:mm:ss"); //gets current date and time
                                    String logTime = sdf1.format(new Date()); //stores current date and time into a string

                                    FirebaseUser rUser = mAuth.getCurrentUser(); //gets the current user info
                                    String userID = rUser.getUid(); //gets user ID
                                    String uEmail0 = rUser.getEmail(); //gets user email ***important***
                                    String uEmail = uEmail0.replaceAll("\\.", ""); //removes periods from user email because Firebase can't have database children with the . character
                                    main_rtdb = FirebaseDatabase.getInstance().getReference("users").child(uEmail); //gets instance at the database location where the new user will go

                                    HashMap<String, String> hashMap = new HashMap<>(); //creates HashMap object, basically what we use to write to database
                                    //make sure these values are written to the database in this same order as shown below
                                    hashMap.put("userID", userID);
                                    hashMap.put("first_name", fname);
                                    hashMap.put("last_name", lname);
                                    hashMap.put("classification", classification);
                                    hashMap.put("date_of_birth", dob);
                                    hashMap.put("phone_number", phone_num);
                                    hashMap.put("email_address", email);
                                    hashMap.put("account_created", logTime); //do not update this field, account creation time must remain the same
                                    main_rtdb.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if(task.isSuccessful()) {
                                                // Sign in success, update UI with the signed-in user's information
                                                Log.d(TAG, "createUserWithEmail:success");
                                                FirebaseUser user = mAuth.getCurrentUser();
                                                Toast.makeText(CreateAccountActivity.this, "Profile creation successful.",
                                                        Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                                } else {
                                    // If sign in fails, display a message to the user.
                                    Log.w(TAG, "createUserWithEmail:failure", task.getException());
                                    Toast.makeText(CreateAccountActivity.this, "User creation failed.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                Intent myIntent = new Intent(CreateAccountActivity.this, MainActivity.class);
                CreateAccountActivity.this.startActivity(myIntent);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(CreateAccountActivity.this, MainActivity.class);
                CreateAccountActivity.this.startActivity(myIntent);
            }
        });
    }

    private void reload() {
        mAuth.getCurrentUser().reload().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {

                } else {
                    Log.e(TAG, "reload", task.getException());
                }
            }
        });
    }
}