package com.example.intheknow;

import android.app.Activity;

public class Edit extends Activity {
}
