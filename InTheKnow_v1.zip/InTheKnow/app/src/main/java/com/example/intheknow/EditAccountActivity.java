package com.example.intheknow;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;


public class EditAccountActivity extends AppCompatActivity {
    private DatabaseReference main_rtdb;
    private FirebaseAuth mAuth;
    String dob = "";
    String email_address = "";
    String account_created = "";
    String uid = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_account2);
        main_rtdb = FirebaseDatabase.getInstance().getReference();
        mAuth = FirebaseAuth.getInstance();
        FirebaseUser rUser = mAuth.getCurrentUser(); //gets the current user info
        String uEmail0 = rUser.getEmail();
        String uEmail = uEmail0.replaceAll("\\.", ""); //removes periods from user email because Firebase can't have database children with the . character
        main_rtdb = FirebaseDatabase.getInstance().getReference("users").child(uEmail);

        Button b1, b2;
        EditText ed1, ed2, ed3, ed4;
        TextView tv1;

        b1 = (Button) findViewById(R.id.newlog); //done button
        b2 = (Button) findViewById(R.id.button02); //cancel button

        ed1 = (EditText) findViewById(R.id.editText); //first name
        ed2 = (EditText) findViewById(R.id.editText10); //last name
        ed3 = (EditText) findViewById(R.id.editText11); //classification
        ed4 = (EditText) findViewById(R.id.editText13); //phone number

        tv1 = (TextView) findViewById(R.id.textview3);
        tv1.setText(uEmail0); //display user email on Edit Account Screen

        main_rtdb = FirebaseDatabase.getInstance().getReference(); //get new reference of database
        main_rtdb.child("users").child(uEmail).child("first_name").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    String fname = String.valueOf(task.getResult().getValue());
                    ed1.setText(fname);
                }
            }
        });

        main_rtdb.child("users").child(uEmail).child("last_name").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    String lname = String.valueOf(task.getResult().getValue());
                    ed2.setText(lname);
                }
            }
        });

        main_rtdb.child("users").child(uEmail).child("classification").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    String classification = String.valueOf(task.getResult().getValue());
                    ed3.setText(classification);
                }
            }
        });

        main_rtdb.child("users").child(uEmail).child("phone_number").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    String phone_num = String.valueOf(task.getResult().getValue());
                    ed4.setText(phone_num);
                }
            }
        });

        main_rtdb.child("users").child(uEmail).child("userID").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    uid = String.valueOf(task.getResult().getValue());
                }
            }
        });

        main_rtdb.child("users").child(uEmail).child("account_created").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    account_created = String.valueOf(task.getResult().getValue());
                }
            }
        });

        main_rtdb.child("users").child(uEmail).child("date_of_birth").get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (!task.isSuccessful()) {
                    Log.e("firebase", "Error getting data", task.getException());
                }
                else {
                    Log.d("firebase", String.valueOf(task.getResult().getValue())); //this is what actually gets the data we want
                    dob = String.valueOf(task.getResult().getValue());
                }
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String fname1 = ed1.getText().toString();
                String lname1 = ed2.getText().toString();
                String classification1 = ed3.getText().toString();
                String phone_num1 = ed4.getText().toString();

                while(fname1.isEmpty()) {
                    Toast.makeText(EditAccountActivity.this, "Please enter your first name!", Toast.LENGTH_SHORT).show();
                    return;
                }

                while(lname1.isEmpty()) {
                    Toast.makeText(EditAccountActivity.this, "Please enter your last name!", Toast.LENGTH_SHORT).show();
                    return;
                }

                while(classification1.isEmpty()) {
                    Toast.makeText(EditAccountActivity.this, "Please enter your classification!", Toast.LENGTH_SHORT).show();
                    return;
                }

                while(phone_num1.isEmpty()) {
                    Toast.makeText(EditAccountActivity.this, "Please enter your phone number!", Toast.LENGTH_SHORT).show();
                    return;
                }

                //-------------------------
                main_rtdb = FirebaseDatabase.getInstance().getReference("users").child(uEmail); //gets instance at the database location where the new user will go

                HashMap<String, String> hashMap = new HashMap<>(); //creates HashMap object, basically what we use to write to database
                //make sure these values are written to the database in this same order as shown below

                hashMap.put("userID", uid);
                hashMap.put("first_name", fname1); //updated
                hashMap.put("last_name", lname1); //updated
                hashMap.put("classification", classification1); //updated
                hashMap.put("date_of_birth", dob);
                hashMap.put("phone_number", phone_num1); //updated
                hashMap.put("email_address", uEmail0);
                hashMap.put("account_created", account_created);

                main_rtdb.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()) {
                            // Sign in success, update UI with the signed-in user's information
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(EditAccountActivity.this, "Account update successful.", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                //-------------------------

                Toast.makeText(EditAccountActivity.this, "Account updated successfully.", Toast.LENGTH_SHORT).show();
                Intent myIntent = new Intent(EditAccountActivity.this, HomeActivity.class);
                EditAccountActivity.this.startActivity(myIntent);
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntent = new Intent(EditAccountActivity.this, HomeActivity.class);
                EditAccountActivity.this.startActivity(myIntent);
            }
        });

    }
}
