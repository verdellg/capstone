package com.example.intheknow;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

public class NewLogActivity extends AppCompatActivity {
    private DatabaseReference main_rtdb;
    private static final String TAG = "EmailPassword";
    private FirebaseAuth mAuth;
    static final int REQUEST_IMAGE_CAPTURE = 1;

    SimpleDateFormat sdf = new SimpleDateFormat("MMddyyyy_HHmmss");
    String currD_T = sdf.format(new Date());

    String filename = "";
    FirebaseStorage storage = FirebaseStorage.getInstance();
//    String usrEmail = getIntent().getExtras().getString("uEmail");
    StorageReference storageRef = storage.getInstance().getReference("temperature_confirmations/" + "__LOG__" + currD_T);
    boolean imgUpload = false;

    ImageView imgv1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_log);
        mAuth = FirebaseAuth.getInstance();

        TextView textView=findViewById(R.id.textview_date);
        SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
        String currentDateandTime = sdf.format(new Date());
        textView.setText(currentDateandTime);


        CheckBox chkbx1, chkbx2, chkbx3, chkbx4, chkbx5, chkbx6, chkbx7;
        Button b1, b2, b3;

        chkbx1 = (CheckBox) findViewById(R.id.chbx1);
        chkbx2 = (CheckBox) findViewById(R.id.chbx2);
        chkbx3 = (CheckBox) findViewById(R.id.chbx3);
        chkbx4 = (CheckBox) findViewById(R.id.chbx4);
        chkbx5 = (CheckBox) findViewById(R.id.chbx5);
        chkbx6 = (CheckBox) findViewById(R.id.chbx6);
        chkbx7 = (CheckBox) findViewById(R.id.chbx7);

        CheckBox finalChbx1 = chkbx1;
        CheckBox finalChbx2 = chkbx2;
        CheckBox finalChbx3 = chkbx3;
        CheckBox finalChbx4 = chkbx4;
        CheckBox finalChbx5 = chkbx5;
        CheckBox finalChbx6 = chkbx6;
        CheckBox finalChbx7 = chkbx7;

        b1 = (Button) findViewById(R.id.button2);
        b2 = (Button) findViewById(R.id.button3);
        b3 = (Button) findViewById(R.id.newlog);

    //    imgv1 = (ImageView) findViewById(R.id.imageView1);


        //symptom variables
        boolean fever = false; //fever
        boolean cough = false; //cough
        boolean headache = false; //headache
        boolean fatigue = false; //fatigue
        boolean congestion = false; //congestion
        boolean taste = false; //loss of taste/smell
        boolean no_sympt = false; //none



        //submit button
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //String symptoms_list = "";
                String symptoms_list_final = "";
                String fever = "-fever-";
                String cough = "-cough/sore throat-";
                String headache = "-headache-";
                String fatigue = "-fatigue-";
                String congestion = "-congestion-";
                String loss_of_senses = "-loss of taste/smell-";
                String none = "-NO SYMPTOMS-";

                //local vars for checkboxes
                boolean chb1 = finalChbx1.isChecked();
                boolean chb2 = finalChbx2.isChecked();
                boolean chb3 = finalChbx3.isChecked();
                boolean chb4 = finalChbx4.isChecked();
                boolean chb5 = finalChbx5.isChecked();
                boolean chb6 = finalChbx6.isChecked();
                boolean chb7 = finalChbx7.isChecked();
                boolean anyChecked = false;

                if(chb1 || chb2 || chb3 || chb4 || chb5 || chb6 || chb7) {
                    anyChecked = true;
                }

                while(!anyChecked) {
                    Toast.makeText(NewLogActivity.this, "ERROR: User must check one of the boxes first!", Toast.LENGTH_LONG).show();
                    return;
                }

                while(!imgUpload) {
                    Toast.makeText(NewLogActivity.this, "ERROR: User must upload an image first!", Toast.LENGTH_LONG).show();
                    return;
                }

                if(chb1) {
                    symptoms_list_final = symptoms_list_final + fever;
                }

                if(chb2) {
                    symptoms_list_final = symptoms_list_final + cough;
                }

                if(chb3) {
                    symptoms_list_final = symptoms_list_final + headache;
                }

                if(chb4) {
                    symptoms_list_final = symptoms_list_final + fatigue;
                }

                if(chb5) {
                    symptoms_list_final = symptoms_list_final + congestion;
                }

                if(chb6) {
                    symptoms_list_final = symptoms_list_final + loss_of_senses;
                }

                if(chb7) {
                    symptoms_list_final = symptoms_list_final + none;
                }

                while((chb7 && chb1) || (chb7 && chb2) || (chb7 && chb3) || (chb7 && chb4) || (chb7 && chb5) || (chb7 && chb6)) {
                    Toast.makeText(NewLogActivity.this, "ERROR: User cannot select None along with other symptoms!", Toast.LENGTH_LONG).show();
                    return;
                }

                FirebaseUser rUser = mAuth.getCurrentUser();
                String uEmail0 = rUser.getEmail();
                String uEmail = uEmail0.replaceAll("\\.", "");


                SimpleDateFormat sdf1 = new SimpleDateFormat("MM/dd/yyyy 'at' HH:mm:ss");
                SimpleDateFormat sdf2 = new SimpleDateFormat("MMddyyyy_HHmmss");
                String logTime = sdf1.format(new Date());
                String logNameTime = sdf2.format(new Date());
                main_rtdb = FirebaseDatabase.getInstance().getReference("logs").child(uEmail + "__" + logNameTime);

                HashMap<String, String> hashMap = new HashMap<>();
                hashMap.put("user", uEmail);
                hashMap.put("log_created", logTime);
                hashMap.put("symptoms", symptoms_list_final);
                main_rtdb.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()) {
                            Toast.makeText(NewLogActivity.this, "Log submitted successfully.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(NewLogActivity.this, "Log was not submitted due to an error!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                Intent myIntent = new Intent(NewLogActivity.this, HomeActivity.class);
                NewLogActivity.this.startActivity(myIntent);
            }
        });

        //cancel button
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent(NewLogActivity.this, HomeActivity.class);
                NewLogActivity.this.startActivity(myIntent);
            }
        });

        //upload image button
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                while(imgUpload) {
                    Toast.makeText(NewLogActivity.this, "ERROR: An image has already been uploaded for this log!", Toast.LENGTH_LONG).show();
                    return;
                }
                dispatchTakePictureIntent();

            }
        });

    }

    @Override
    public void onBackPressed() {
        Toast.makeText(NewLogActivity.this,
                "The back button is disabled for this screen.",
                Toast.LENGTH_LONG).show();
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        try {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } catch (ActivityNotFoundException e) {
            // display error state to the user
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, baos);
            byte[] data1 = baos.toByteArray();


            UploadTask uploadTask = storageRef.putBytes(data1);
            imgUpload = true;
            uploadTask.addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception exception) {

                }
            }).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                }
            });
        }
    }
}